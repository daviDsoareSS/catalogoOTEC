<div class="card-products">
    <h3>PROCEDIMENTOS</h3>
    <ul>                 
        <li class="selected">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/toxina-botulinica">
                <div class="link">
                    &bull; Toxina Botulínica
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/preenchimento">
                <div class="link">
                    &bull; Preenchimento
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/bioestimulador-de-colageno">
                <div class="link">
                    &bull; Bioestimulador de colágeno
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/ultraformer">
                <div class="link">
                    &bull; Ultraformer
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/lavieen">
                <div class="link">
                    &bull; Lavieen
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/endolaser">
                <div class="link">
                    &bull; Endolaser
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/luz-intensa-pulsada">
                <div class="link">
                    &bull; Luz intensa pulsada
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/microagulhamento">
                <div class="link">
                    &bull; Microagulhamento
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/jato-de-plasma">
                <div class="link">
                    &bull; Jato de plasma
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/mesoterapia-enzimas">
                <div class="link">
                    &bull; Mesoterapia - Enzimas
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/peeling">
                <div class="link">
                    &bull; Peeling
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/radiofrequencia">
                <div class="link">
                    &bull; Radiofrequência
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/limpeza-de-pele">
                <div class="link">
                    &bull; Limpeza de pele
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/ultracavitacao-lipocavitacao">
                <div class="link">
                    &bull; Ultracavitação - Lipocavitação
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/fototerapia">
                <div class="link">
                    &bull; Fototerapia
                </div>
            </a>
        </li>
        <li class="">
            <a href="https://www.clinicanatallilandi.com.br/procedimentos/drenagem-linfatica">
                <div class="link">
                    &bull; Drenagem linfática
                </div>
            </a>
        </li>
    </ul>
</div>