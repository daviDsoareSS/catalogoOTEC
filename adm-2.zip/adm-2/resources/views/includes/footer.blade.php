<footer>
    <div class="content">
        <a href="">
            <img id="logo" src="{{ asset('img/logoOTECShop.webp')}}" alt="" title="Logo"  width="300" height="87">
        </a>
        <div class="wrapper-footer">
            <div class="content-link about">
                <h3>SOBRE</h3>
                <p>
                    <a href="">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed eiusmod tempor incididunt ut labore et dolore magna aliqua. enim ad minim veniam, quis nos trud exerci tation ullamc olab oris nisi ut aliquip ex ea commodo consequat.
                    </a>
                </p>
            </div>
            <div class="content-link pages">
                <h3>PÁGINAS</h3>
                <div class="group-links">
                    <ul>
                        <li class="{{ url()->current() === url('/a-clinica') ? 'selected' : '' }}">
                            <a href="">
                                A clínica
                            </a>
                        </li>
                        <li class="{{ url()->current() === url('/especialidades') ? 'selected' : '' }}">
                            <a href="">
                                Especialidades
                            </a>
                        </li>
                        <li class="{{ url()->current() === url('/dicas-uteis') ? 'selected' : '' }}">
                            <a href="">
                                Dicas úteis
                            </a>
                        </li>
                        <li class="{{ url()->current() === url('/procedimentos') ? 'selected' : '' }}">
                            <a href="">
                                Procedimentos
                            </a>
                        </li>
                        <li class="{{ url()->current() === url('/contato') ? 'selected' : '' }}">
                            <a href="">
                                Contato
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="content-link contact">
                <h3>CONTATO</h3>
                <ul>
                    <li>
                        <a href="{{ getItem('link-whats1') }}" target="_blank">
                            <i class="fa-brands fa-whatsapp"></i>
                            {{ getItem('whats1') }} 
                        </a>
                    </li>
                    <li>
                        <a href="{{ getItem('instagram') }}" target="__blank">
                            <i class="fa-brands fa-instagram"></i>
                            {{ getItem('nome-instagram') }}
                        </a>
                    </li>
                    <li>
                        <a href="{{ getItem('email-link') }}">
                            <i class="fa-regular fa-envelope"></i>
                            {{ getItem('email-client') }}
                        </a>
                    </li>
                    <li> 
                        <a href="{{ getItem('link-local-client') }}" target="_blank" style="align-items: start;">
                            <i class="fa-solid fa-location-pin" style="transform: translateY(4px);"></i>
                            {!! getItem('local-client') !!}
                        </a>
                    </li>
                </ul>  
            </div>
        </div>
    </div>
</footer>
<div class="byEngenho">
    <a href="https://www.engenhodeimagens.com.br/" target="_blank">
        <picture>
            <source srcset="{{ asset('img/desenvolvido-por-engenho-de-imagens.webp')
        }}" type="image/webp">
            <source srcset="{{ asset('img/desenvolvido-por-engenho-de-imagens.png')}}" type="image/png">
            <img src="{{ asset('img/desenvolvido-por-engenho-de-imagens.webp')
        }}" alt="Engenho de imagens" loading="lazy" width="317" height="22">
        </picture>
    </a>
</div>