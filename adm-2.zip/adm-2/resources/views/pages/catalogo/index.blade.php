@extends('layout.layout')
@section('head')
    <link rel="stylesheet" href="{{ asset('css/catalogo.css') }}">
@endsection
@section('content')
    <main>
        <img src="{{ asset('img/banner-main.webp') }}" alt="">
    </main>
    @include('includes.menu-products')
@endsection