<html>
    <h2>Email recebido de Lead {{ $url }}</h2>
    <hr>
    <strong>O número {{ $telefone }} deseja receber os informativos da {{ getItem('client') }}.</strong>
</html>