<?php

return [
    'failed' => 'Essas credenciais não foram encontradas em nossos registros.',
    // other translation keys
];