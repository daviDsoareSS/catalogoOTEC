<?php if(session()->has('success')): ?>
    <div class="message message-success" id="message-success">
        <p><i class="fa-solid fa-check"></i> <?php echo e(session()->get('success')); ?></p>
    </div>
<?php endif; ?>
<?php if(session()->has('delete')): ?>
    <div class="message message-delete">
        <p><i class="fa-solid fa-check"></i> <?php echo e(session()->get('delete')); ?><p>
    </div>
<?php else: ?>
    <div class="message message-delete" style="display: none;">
        <i class="fa-solid fa-check"></i>
        <p id="message"> Itens deletados com sucesso!<p>
    </div>
<?php endif; ?>

<script>
    function ocultMessageContent(message){
        message.style.opacity = 0;
    }
    setTimeout(function() {
        var successMessage = document.getElementById('message-success');
        ocultMessageContent(successMessage);
    }, 3000);
</script><?php /**PATH C:\Users\engenho-08\Documents\Catálogo Ametista\adm-2\resources\views/adm/includes/messages.blade.php ENDPATH**/ ?>