<header>
    <div class="btnMobile">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <div class="title-page">
        <?php if(stripos(request()->route()->getName(), 'index') === false): ?>
            <a href="<?php echo e(redirect()->back()->getTargetUrl()); ?>">
                <h1>
                    <i class="fa-solid fa-circle-arrow-left"></i>
                    <?php echo $__env->yieldContent('title'); ?>
                </h1>
            </a>
        <?php else: ?>
            <h1>
                <i class="fa-solid fa-house-chimney"></i>
                <?php echo $__env->yieldContent('title'); ?>
            </h1>
        <?php endif; ?>
    </div>
    <ul class="links-header">
        <li class="link option-notification" id="li">
            <i class="fa-solid fa-bell notifications"></i>

            <?php if(count($notificacaoLeads) > 0): ?>
                <span class="badge badge-danger navbar-badge-news" id="leadscount">
                    <?php echo e(count($notificacaoLeads)); ?>

                </span>
            <?php endif; ?>

            <div class="options-collapsed notifications" id="linkleadsNotifications">
                <?php $__currentLoopData = $notificacaoLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('leads.edit', $lead->id)); ?>" class="media-link">
                        <div class="media">
                            <div class="text">
                                <h4 class="media-titulo"><?php echo e($lead->title); ?></h4>
                                <span class="telefone"><?php echo e($lead->telephone); ?></span><br>
                                <span class="time"><i class="fa-regular fa-clock"></i> <?php echo e(runningTime($lead['created_at'])); ?></span>
                            </div>
                        </div>
                    </a>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(!$notificacaoLeads): ?>
                    <p>Nada encontrado.</p>
                <?php else: ?>
                    <div class="total-news">
                        <a href="<?php echo e(route('leads.index')); ?>"><p>Veja todas as news</p></a>
                    </div>
                <?php endif; ?>
            </div>
        </li>
        <li class="link option-notification">
        <i class="fa-solid fa-message"></i>
            <?php if(count($notificacaoContatos) > 0): ?>
                <span class="badge badge-danger navbar-badge-contato" id="contatocount">
                    <?php echo e(count($notificacaoContatos)); ?>

                </span>
            <?php endif; ?>

            <div class="options-collapsed notifications" id="linkContatoNotifications">
                <?php $__currentLoopData = $notificacaoContatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('contato.edit', $contato->id)); ?>" class="media-link">
                        <div class="media">
                            <div class="text">
                                <h4 class="media-titulo"><?php echo e($contato->title); ?></h4>
                                <span class="telefone"><?php echo e($contato->telephone); ?></span><br>
                                <span class="time"><i class="fa-regular fa-clock"></i> <?php echo e(runningTime($contato['created_at'])); ?></span>
                            </div>
                        </div>
                    </a>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(!$notificacaoContatos): ?>
                    <p>Nada encontrado.</p>
                <?php else: ?>
                    <div class="total-news">
                        <a href="<?php echo e(route('contato.index')); ?>"><p>Veja todos os contatos</p></a>
                    </div>
                <?php endif; ?>
            </div>
        </li>
        <li class="link">
            <i class="fa-solid fa-circle-half-stroke"></i>
            <div class="options-collapsed colors">
                <ul>
                    <li class="dark-mode-toggle"><i class="fa-solid fa-moon"></i>Modo escuro</li>
                    <li class="white-mode-toggle"><i class="fa-solid fa-sun"></i>Modo claro</li>
                </ul>
            </div>
        </li>
        <li class="wrapper-user">
            <a href="<?php echo e(route('perfil.index')); ?>"><img src="<?php echo e(asset('upload/perfil/'.$user->image)); ?>" alt=""></a>
            <li class="link">
                <p id="name-client"><?php echo e($user->name); ?></p>
                <i class="fa-solid fa-caret-down"></i>
                <div class="options-collapsed more-options">
                    <ul>
                        <a href="<?php echo e(route('perfil.index')); ?>"><li>Perfil</li></a>
                        <a href="<?php echo e(route('logout.perform')); ?>"><li>Sair</li></a>
                    </ul>
                </div>
            </li>
        </li>
    </ul>
</header>

<script>
    const linksHeader = document.querySelectorAll('.links-header .link');
    let openLink = null;

    linksHeader.forEach(function (link) {
        link.addEventListener('click', function () {
            if (openLink && openLink !== link) {
                openLink.classList.remove('collapsed');
            }

            if (link.classList.contains('collapsed')) {
                link.classList.remove('collapsed');
                openLink = null;
            } else {
                link.classList.add('collapsed');
                openLink = link;
            }
            event.stopPropagation();
        });
    });

    document.addEventListener('click', function (event) {
        const isOutsideCollapsed = !event.target.closest('.options-collapsed');

        if (isOutsideCollapsed && openLink) {
            openLink.classList.remove('collapsed');
            openLink = null;
        }
    });

</script>
<?php /**PATH C:\Users\engenho-08\Documents\Catálogo Ametista\adm-2\resources\views/adm/includes/header.blade.php ENDPATH**/ ?>