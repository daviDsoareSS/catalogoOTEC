
<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/catalogo.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <img src="<?php echo e(asset('img/banner-main.webp')); ?>" alt="">
    </main>
    <?php echo $__env->make('includes.menu-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\engenho-08\Documents\Catálogo OTEC Shop\adm-2\resources\views/pages/catalogo/index.blade.php ENDPATH**/ ?>