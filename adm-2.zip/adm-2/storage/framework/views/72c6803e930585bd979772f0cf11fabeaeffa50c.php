<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
</head>
<body>
    <h3>rerere</h3>
</body>
</html><?php /**PATH C:\Users\engenho-08\Documents\Catálogo OTEC Shop\adm-2\resources\views/catalogo/index.blade.php ENDPATH**/ ?>