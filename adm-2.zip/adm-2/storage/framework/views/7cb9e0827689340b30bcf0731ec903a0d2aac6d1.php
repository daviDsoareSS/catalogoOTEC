<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(getItem('client')); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('favicon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('favicon/site.webmanifest')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style-popup.css')); ?>">

    
    <meta name="Title" content="<?php echo $__env->yieldContent('title-seo'); ?>">
    <meta name="Author" content="<?php echo e(getItem('client')); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('description-seo'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords-seo'); ?>">

    
    <meta property="og:title" content="<?php echo $__env->yieldContent('title-seo'); ?>"/>
    <meta property="og:type" content=""/>
    <meta property="og:description" content="<?php echo $__env->yieldContent('description-seo'); ?>"/>
    <meta property="og:image" content="<?php echo e(url('favicon/favicon-32x32.png')); ?>"/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta name="twitter:card" content="">
    <meta property="twitter:url" content=""/>
    <meta property="twitter:title" content="<?php echo $__env->yieldContent('title-seo'); ?>"/>
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('description-seo'); ?>">
    <meta property="twitter:image" content="<?php echo e(url('favicon/favicon-32x32.png')); ?>"/>

    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
    <!--Popup Lgpd-->
    <div class="pop-up-cookie" id="popup">
        <div class="content-wrapper">
            <p>Utilizamos cookies para você obter a melhor experiência em nosso site. Ao continuar navegando, você concorda com a nossa <a href="">Política de Privacidade</a>.</p>
            <a href="javascript:;" itemprop="url" class="btn-privacy" id="privacy-ok">OK</a>
        </div>
    </div> 

    <a href="<?php echo e(getItem('link-whats1')); ?>" target="_blank">
        <div class="btn-whats">
            <img src="<?php echo e(asset('img/whatsapp.png')); ?>" alt="WhatsApp">      
        </div>
    </a>

    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Modal sair-->
    

    <?php if(session()->has('success')): ?>
    <div class="message message-success" id="message-success">
        <p><i class="fa-solid fa-check"></i> <?php echo e(session()->get('success')); ?></p>
    </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
        <div class="message message-error">
            <p><i class="fa-solid fa-check"></i> <?php echo e(session()->get('error')); ?><p>
        </div>
    <?php endif; ?>
        
    <?php echo $__env->yieldContent('content'); ?>
    
    <?php echo $__env->make('includes.section-contato', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldContent('scripts'); ?>
    
    <script src="https://kit.fontawesome.com/639efb6961.js" crossorigin="anonymous"></script>
    <script>
        function ocultMessageContent(message){
            message.style.opacity = 0;
            message.style.display = 'none';
        }
        setTimeout(function() {
            var successMessage = document.getElementById('message-success');
            ocultMessageContent(successMessage);
        }, 3500);
    </script>

</body>

</html><?php /**PATH C:\Users\engenho-08\Documents\Catálogo OTEC Shop\adm-2\resources\views/layout/layout.blade.php ENDPATH**/ ?>