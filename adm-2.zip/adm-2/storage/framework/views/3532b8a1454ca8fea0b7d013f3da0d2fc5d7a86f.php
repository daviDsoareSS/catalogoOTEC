<?php if($errors->any()): ?>
    <div class="message message-delete" style="flex-direction: column;">
        <p><i class="fa-solid fa-check"></i></p>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul>
                <li><?php echo e($error); ?></li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <script>
        const messageContent = document.querySelector('.message');

        function ocultMessageContent(){
            messageContent.style.top = '-50%';
            messageContent.style.opacity = 0;
            
        }
        setTimeout(ocultMessageContent, 3000);
    </script>
<?php endif; ?><?php /**PATH C:\Users\engenho-08\Documents\Catálogo OTEC Shop\adm-2\resources\views/adm/includes/error.blade.php ENDPATH**/ ?>