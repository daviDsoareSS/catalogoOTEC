
<?php $__env->startSection('title', 'Acompanhe - Editar'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('adm.includes.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content">
        <form action="<?php echo e(route('acompanhe.update', $acompanhe->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="title">Título</label>
                        <input class="form-control" type="text" name="title" id="title" placeholder="Título" maxlength="100" required value="<?php echo e($acompanhe->title); ?>">
                        <span id="titlechars" class="form-text">100</span><span class="form-text"> Caracteres restantes</span>
                    </div>
                    <div class="col">
                        <label class="form-label" for="author">Autor</label>
                        <input class="form-control" type="text" name="author" id="author" placeholder="Autor"  value="<?php echo e($acompanhe->author); ?>" required>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="subtitle">Resumo</label>
                <textarea class="form-control" type="text" name="subtitle" id="subtitle" rows="3" class="form-control " maxlength="255" required><?php echo e($acompanhe->subtitle); ?></textarea>
                <span id="subtitlechars" class="form-text">255</span><span class="form-text"> Caracteres restantes</span>
            </div>

            <div class="form-group">
                <div class="row" id="image-section">
                    <div class="col">
                        <div class="col">
                            <label class="form-label" for="type">Tipo da postagem</label>
                            <select onchange="changeOptions(this)" class="form-control" name="type" id="type">
                                <option id="type" value="<?php echo e($acompanhe->type); ?>" selected><?php echo e($acompanhe->type); ?></option>
                                <option id="opTexto" value="texto">Texto</option>
                                <option id="opVideo" value="video">Vídeo</option>
                            </select>
                        </div>
                        <div class="col col-image">
                            <label class="form-label" for="image">Imagem</label>
                            <input class="form-control" type="file" name="image" id="inputImage" onchange="PreviewImage();">
                            <span class="text-danger">Obs: formatos recomendados (.jpg .png) com 72dpi e tamanho maximo de 5MB</span>
                            <span style="display: flex; color: #b22; ">Obs: Resolução de imagem recomendada:&nbsp;<strong>800 x 400</strong></span><br>
                            <input type="checkbox" name="converter" id="converter" checked>
                            <label class="form-label" for="converter"> Converter a imagem para .webp?</label>
                            <div class="explanation">
                                <em>
                                <p>Mantenha selecionada essa opção para converter sua imagem para um formato mais otimizado e mais leve.</p>
                                </em>
                            </div>
                        </div>
                        <div class="col col-video">
                            <label class="form-label" for="video">Vídeo</label>
                            <p>*Obs. coloque somente o conteúdo da URL que está em vermelho.
                                <br>
                                Exemplo: https://www.youtube.com/watch?v=<strong style="color: red;">CPRx_WVkJ8g</strong>
                            </p>
                            <input maxlength="11" id="uploadVideo" onkeyup="CountCaracters($(this).val().length, 'video')" class="form-control" type="text" name="video" style="display: block" value="<?php echo e($acompanhe->video); ?>"/>
                        </div>

                    </div>
                    <div class="col">
                        <img src="<?php echo e($acompanhe->image ? asset('upload/acompanhe/'.$acompanhe->image) : asset('upload/acompanhe/notfound.png')); ?>" width="100%" id="uploadPreviewImage" alt="">
                        <iframe class="iframe-video" id="uploadPreviewVideo" width="100%" height="100%" src="https://www.youtube.com/embed/<?php echo e($acompanhe->video); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>

            </div>
            <div class="form-group">
                <label class="form-label" for="text">Conteúdo</label>
                <textarea class="ckeditor form-control" id="ckeditor" name="text"><?php echo e($acompanhe->text); ?></textarea>
            </div>
            <br>
            <div class="form-group">
                <div class="row">
                    <div class="col">
                        <div class="form-check">
                            <input class="form-check-input publicar-agora" type="radio" name="flexRadioDefault" id="agora">
                            <label class="form-check-label" for="agora">
                                Publicar agora
                            </label>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-check">
                            <input class="form-check-input agendar" type="radio" name="flexRadioDefault" id="agendar" >
                            <label class="form-check-label" for="agendar">
                                Agendar publicação
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group form-agendamento disable">
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="date">Data</label>
                        <input class="form-control" type="date" name="date" value="<?php echo e($data); ?>">
                    </div>
                    <div class="col">
                        <label class="form-label" for="time">Horário</label>
                        <input class="form-control" type="time" name="time" value="<?php echo e($acompanhe->time); ?>">
                    </div>
                </div>
            </div>
            <div class="group-button">
                <input class="btn btn-success" type="submit" value="Editar">
                <a href="<?php echo e(route('acompanhe.index')); ?>" class="btn btn-primary">Voltar</a>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('adm.acompanhe.create-edit-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function () {
            if("<?php echo e($acompanhe->status); ?>" === "Pendente") {
                $('#agendar').prop('checked', true);
            }
            let selectedValue = $('#type').val();

            if (selectedValue === 'texto') {
                $('#opTexto').remove();
                MostrarImagem();
            }
            else if (selectedValue === 'video') {
                $('#opVideo').remove();
                MostrarIframe();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\engenho-08\Documents\Catálogo Ametista\adm-2\resources\views/adm/acompanhe/edit.blade.php ENDPATH**/ ?>