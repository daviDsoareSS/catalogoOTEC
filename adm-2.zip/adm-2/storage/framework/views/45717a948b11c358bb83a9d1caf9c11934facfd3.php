
<?php $__env->startSection('title', 'Clientes - Criar'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('adm.includes.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content">
        <form action="<?php echo e(route('clientes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="title">Nome</label>
                        <input class="form-control" type="text" name="nome" placeholder="Digite o nome do cliente" required>
                    </div>
                    <div class="col">
                        <label class="form-label" for="title">CPF</label>
                        <input class="form-control" type="text" name="cpf" placeholder="Digite o CPF do cliente" required>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="email">E-mail</label>
                        <input class="form-control" type="email" name="email" placeholder="Digite e-mail do cliente" required>
                    </div>
                    <div class="col">
                        <label class="form-label" for="telefone">Telefone</label>
                        <input class="form-control" type="text" id="telefone" name="telefone" placeholder="Digite o número de telefone do cliente" required>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="telefone">CEP</label>
                        <input class="form-control" type="text" id="cep" name="cep" placeholder="Digite o cep de telefone do cliente" required>
                    </div>
                    <div class="col">
                        <label class="form-label" for="telefone">Endereço</label>
                        <input class="form-control" type="text" id="endereco" name="endereco" placeholder="Digite o endereço do cliente" required>
                    </div>
                    <div class="col">
                        <label class="form-label" for="telefone">UF</label>
                        <input class="form-control" type="text" id="uf" name="uf" placeholder="Digite o UF do cliente" required>
                    </div>
                    <div class="col">
                        <label class="form-label" for="telefone">UF</label>
                        <input class="form-control" type="text" id="uf" name="uf" placeholder="Digite o UF do cliente" required>
                    </div>
                </div>
            </div>

            <br>
            <div class="group-button">
                <input class="btn btn-success" type="submit" value="Salvar">
                <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-primary">Voltar</a>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('adm.contato.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\engenho-08\Documents\Catálogo OTEC Shop\adm-2\resources\views/adm/clientes/create.blade.php ENDPATH**/ ?>