
<?php $__env->startSection('title', 'Acompanhe'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('adm.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content">
        <div class="info">
            <div class="row">
                <div class="col" style="display: flex; align-items: center;">
                    <a href="<?php echo e(route('acompanhe.create')); ?>" class="btn btn-success btn-create"><span>Cadastrar  </span><i class="fa-solid fa-plus"></i></a>

                    <a href="<?php echo e(route('acompanhe.order')); ?>" class="btn btn-move"><span>Ordenar  </span><i class="fa-solid fa-arrows-up-down-left-right"></i></a>

                    <button class="btn btn-delete" data-bs-toggle="modal" data-bs-target="#delete-all" onclick="sendSelecteds()"></button>

                    <div class="modal fade" id="delete-all" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Deseja deletar os itens selecionados?</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <p class="text"></p>
                                    <ul></ul>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                    <button id="btn-delete-all" class="btn btn-outline-danger" data-item-id="">Deletar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="table">
                <table class="table-acompanhe" id="example">
                    <thead>
                        <tr style="border-bottom: 0px">
                            <th>Selecione</th>
                            <th data-sortas="case-insensitive">Postagem</th>
                            <th>Autor</th>
                            <th data-sortas="datetime">Data e hora</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                    <?php $__currentLoopData = $acompanhelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acompanhe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-title="Selecione" class="checkbox-items">
                                <input type="checkbox" value="<?php echo e($acompanhe->id); ?>">
                            </td>
                            <td class="title">
                                <a href="<?php echo e(route('acompanhe.edit', $acompanhe->id)); ?>">
                                    <?php echo e($acompanhe->title); ?>

                                </a>
                            </td>
                            <td data-title="Autor" class="author">
                                <a href="<?php echo e(route('acompanhe.edit', $acompanhe->id)); ?>">
                                    <?php echo e($acompanhe->author); ?>

                                </a>
                            </td>
                            <td data-title="Data" class="date" data-sortas="datetime">
                                <a href="<?php echo e(route('acompanhe.edit', $acompanhe->id)); ?>">
                                    <?php echo e($acompanhe->datePost); ?>

                                </a>
                            </td>

                            <?php if($acompanhe->order == 1 && $acompanhe->status == 'Publicado'): ?>
                                <td data-title="Status" class="status-principal">
                                    <a href="<?php echo e(route('acompanhe.edit', $acompanhe->id)); ?>">
                                        Conteúdo príncipal
                                    </a>
                                </td>
                            <?php else: ?>
                                <td data-title="Status" class="<?php echo e($acompanhe->status == 'Publicado' ? 'status-publicado' : 'status-pendente'); ?>">
                                    <a href="<?php echo e(route('acompanhe.edit', $acompanhe->id)); ?>">
                                        <?php echo e($acompanhe->status); ?>

                                    </a>
                                </td>
                            <?php endif; ?>

                            <td data-title="Ações">
                                <div class="wrapper-action">
                                    <a class="action-edit" href="<?php echo e(route('acompanhe.edit', $acompanhe->id)); ?>"><i class="fa-solid fa-pen"></i></a>
                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete<?php echo e($acompanhe->id); ?>">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>

                        <!-- Modal -->
                        <div class="modal fade" id="delete<?php echo e($acompanhe->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Deseja deletar? <?php echo e($acompanhe->title); ?></h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Essa ação tem efeito permanente.
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-outline-danger delete-item" data-item-id="<?php echo e($acompanhe->id); ?>">Deletar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/jquery-3.6.4.min.js')); ?>"></script>
    <?php echo $__env->make('adm.includes.datatable', ['tableid' => 'example'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('adm.includes.ajax.delete', ['route' => 'acompanhe'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('adm.includes.ajax.select', ['route' => 'acompanhe', 'column' => 'title'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\engenho-08\Documents\Catálogo Ametista\adm-2\resources\views/adm/acompanhe/index.blade.php ENDPATH**/ ?>